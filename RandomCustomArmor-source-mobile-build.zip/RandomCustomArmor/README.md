# RandomCustomArmor

A Paper 1.21.11 plugin source project. It adds one random custom netherite armor piece to supported structure loot tables with a 3% chance per generated structure chest.

## Armor abilities

- **Titan Chestplate:** +20 maximum health points (+10 hearts) while equipped.
- **Aegis Helmet:** Absorption II while equipped.
- **Berserker Leggings:** Strength I while equipped.
- **Swift Boots:** Speed II while equipped.

Each piece is identified using persistent item data, not its display name. Abilities are applied automatically while worn.

## Build

Requires Java 21 and Gradle. From this project folder, run:

```bash
gradle clean build
```

The plugin JAR will be created in `build/libs/`.

## Build on Android without installing Java/Gradle

1. Extract this ZIP on your phone.
2. Create a GitHub repository and upload the contents of the `RandomCustomArmor` folder (not the outer folder).
3. Open the repository's **Actions** tab.
4. Select **Build RandomCustomArmor** and tap **Run workflow** (or wait for the first push build).
5. Open the completed workflow run, scroll to **Artifacts**, and download `RandomCustomArmor-1.0.0`.
6. Extract the artifact ZIP. It contains `RandomCustomArmor-1.0.0.jar`.
7. Upload that JAR to your server's `plugins` folder and restart the server.

## Notes

- Loot is added when a supported structure chest's loot is generated. Existing chests that were already generated/looted are not retroactively changed.
- The 3% chance is rolled per supported structure chest loot generation; the armor piece is selected randomly.
- Test on a backup or staging server first. This is source code, not a precompiled or runtime-tested JAR.
