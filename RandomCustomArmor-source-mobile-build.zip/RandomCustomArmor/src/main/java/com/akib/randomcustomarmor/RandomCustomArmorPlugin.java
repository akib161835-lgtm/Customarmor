package com.akib.randomcustomarmor;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.world.LootGenerateEvent;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.EquipmentSlotGroup;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

public final class RandomCustomArmorPlugin extends JavaPlugin implements Listener {
    private static final double DROP_CHANCE = 0.03;
    private NamespacedKey armorKey;
    private NamespacedKey chestHealthKey;

    @Override
    public void onEnable() {
        armorKey = new NamespacedKey(this, "custom_armor_piece");
        chestHealthKey = new NamespacedKey(this, "custom_chest_health");
        getServer().getPluginManager().registerEvents(this, this);
        Bukkit.getScheduler().runTaskTimer(this, this::updateOnlinePlayers, 20L, 20L);
        getLogger().info("RandomCustomArmor enabled. Structure chest drop chance: 3%.");
    }

    @Override
    public void onDisable() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            clearOurEffects(player);
        }
    }

    @EventHandler
    public void onLootGenerate(LootGenerateEvent event) {
        String table = event.getLootTable().getKey().getKey().toLowerCase(Locale.ROOT);
        if (!isSupportedStructureChest(table)) return;
        if (ThreadLocalRandom.current().nextDouble() >= DROP_CHANCE) return;

        ArmorPiece[] pieces = ArmorPiece.values();
        ArmorPiece selected = pieces[ThreadLocalRandom.current().nextInt(pieces.length)];
        event.getLoot().add(createArmor(selected));
    }

    private boolean isSupportedStructureChest(String table) {
        if (!table.startsWith("chests/")) return false;
        return table.contains("ancient_city")
                || table.contains("trial_chambers")
                || table.contains("woodland_mansion")
                || table.contains("bastion")
                || table.contains("end_city")
                || table.contains("nether_bridge")
                || table.contains("desert_pyramid")
                || table.contains("jungle_temple")
                || table.contains("igloo")
                || table.contains("shipwreck")
                || table.contains("buried_treasure")
                || table.contains("stronghold");
    }

    private ItemStack createArmor(ArmorPiece piece) {
        ItemStack item = new ItemStack(piece.material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.LIGHT_PURPLE + "✦ " + ChatColor.BOLD + piece.displayName + " ✦");
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.GRAY + "A relic hidden in ancient structures.");
        lore.add(ChatColor.DARK_PURPLE + "Unique Ability:");
        lore.add(ChatColor.AQUA + piece.abilityDescription);
        lore.add(ChatColor.YELLOW + "Automatically activates when worn.");
        lore.add(ChatColor.DARK_GRAY + "Very Rare • 3% structure chest chance");
        meta.setLore(lore);
        meta.getPersistentDataContainer().set(armorKey, PersistentDataType.STRING, piece.id);

        if (piece == ArmorPiece.CHESTPLATE) {
            meta.addAttributeModifier(Attribute.MAX_HEALTH,
                    new AttributeModifier(chestHealthKey, 20.0, AttributeModifier.Operation.ADD_NUMBER,
                            EquipmentSlotGroup.CHEST));
        }
        item.setItemMeta(meta);
        return item;
    }

    private void updateOnlinePlayers() {
        for (Player player : Bukkit.getOnlinePlayers()) {
            EntityEquipment equipment = player.getEquipment();
            applyOrClear(player, equipment.getHelmet(), ArmorPiece.HELMET,
                    PotionEffectType.ABSORPTION, 1);
            applyOrClear(player, equipment.getChestplate(), ArmorPiece.CHESTPLATE, null, 0);
            applyOrClear(player, equipment.getLeggings(), ArmorPiece.LEGGINGS,
                    PotionEffectType.STRENGTH, 0);
            applyOrClear(player, equipment.getBoots(), ArmorPiece.BOOTS,
                    PotionEffectType.SPEED, 1);
        }
    }

    private void applyOrClear(Player player, ItemStack item, ArmorPiece piece,
                              PotionEffectType effect, int amplifier) {
        boolean wearing = isOurPiece(item, piece);
        if (effect == null) return;
        if (wearing) {
            player.addPotionEffect(new PotionEffect(effect, 45, amplifier, true, false, true));
        } else {
            PotionEffect current = player.getPotionEffect(effect);
            if (current != null && current.getAmplifier() == amplifier && current.getDuration() <= 45) {
                player.removePotionEffect(effect);
            }
        }
    }

    private boolean isOurPiece(ItemStack item, ArmorPiece expected) {
        if (item == null || item.getType() != expected.material || !item.hasItemMeta()) return false;
        String id = item.getItemMeta().getPersistentDataContainer().get(armorKey, PersistentDataType.STRING);
        return expected.id.equals(id);
    }

    private void clearOurEffects(Player player) {
        removeIfMatching(player, PotionEffectType.ABSORPTION, 1);
        removeIfMatching(player, PotionEffectType.STRENGTH, 0);
        removeIfMatching(player, PotionEffectType.SPEED, 1);
    }

    private void removeIfMatching(Player player, PotionEffectType type, int amplifier) {
        PotionEffect current = player.getPotionEffect(type);
        if (current != null && current.getAmplifier() == amplifier && current.getDuration() <= 45) {
            player.removePotionEffect(type);
        }
    }

    @EventHandler public void onJoin(PlayerJoinEvent event) {
        Bukkit.getScheduler().runTask(this, () -> updatePlayer(event.getPlayer()));
    }
    @EventHandler public void onRespawn(PlayerRespawnEvent event) {
        Bukkit.getScheduler().runTask(this, () -> updatePlayer(event.getPlayer()));
    }
    @EventHandler public void onInventoryClick(InventoryClickEvent event) {
        if (event.getWhoClicked() instanceof Player player) {
            Bukkit.getScheduler().runTask(this, () -> updatePlayer(player));
        }
    }
    @EventHandler public void onInventoryClose(InventoryCloseEvent event) {
        if (event.getPlayer() instanceof Player player) {
            Bukkit.getScheduler().runTask(this, () -> updatePlayer(player));
        }
    }

    private void updatePlayer(Player player) {
        if (!player.isOnline()) return;
        EntityEquipment equipment = player.getEquipment();
        applyOrClear(player, equipment.getHelmet(), ArmorPiece.HELMET, PotionEffectType.ABSORPTION, 1);
        applyOrClear(player, equipment.getChestplate(), ArmorPiece.CHESTPLATE, null, 0);
        applyOrClear(player, equipment.getLeggings(), ArmorPiece.LEGGINGS, PotionEffectType.STRENGTH, 0);
        applyOrClear(player, equipment.getBoots(), ArmorPiece.BOOTS, PotionEffectType.SPEED, 1);
    }

    private enum ArmorPiece {
        HELMET("helmet", Material.NETHERITE_HELMET, "Aegis Helmet", "Absorption II"),
        CHESTPLATE("chestplate", Material.NETHERITE_CHESTPLATE, "Titan Chestplate", "+10 extra hearts"),
        LEGGINGS("leggings", Material.NETHERITE_LEGGINGS, "Berserker Leggings", "Strength I"),
        BOOTS("boots", Material.NETHERITE_BOOTS, "Swift Boots", "Speed II");

        private final String id;
        private final Material material;
        private final String displayName;
        private final String abilityDescription;
        ArmorPiece(String id, Material material, String displayName, String abilityDescription) {
            this.id = id;
            this.material = material;
            this.displayName = displayName;
            this.abilityDescription = abilityDescription;
        }
    }
}
